#ifndef __LMAP_H__
#define __LMAP_H__
#include "lLine.h"
#include "dhVector.h"
#include "dhMat.h"
#include <QPainter>
class lMap{
public:
	lMap();
	~lMap();
public:
	void Initialzation();
	void Init(int nln,int nvt);
	void Close();
public:
	lLine *pLn;
	int nLn;
	dhVector *pVt;
	int nVt;
	dhMat h;
	float s;
public:
	void Load(const char*);
	void Draw(QPainter*);
	void BoxMap(int, int);
};
#endif
