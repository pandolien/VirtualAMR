#include <stdio.h>
#include <string.h>
#include <QApplication>
#include "CMainWin.h"
