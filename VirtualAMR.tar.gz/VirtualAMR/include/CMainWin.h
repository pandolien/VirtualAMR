#ifndef __CMAINWIN_H__
#define __CMAINWIN_H__
#include <QtWidgets>
#include <QTimer>
#include <QPainter>
#include <QScrollBar>


#include <ros/ros.h>
#include <ros/spinner.h>

#include "lDiff.h"
#include "lLidar.h"
#include "lMap.h"
class CMainWin:public QWidget{
public:
	CMainWin(QWidget *parent = NULL) : QWidget(parent) {
		Intialzation();
		Init();
	}
private://Evnet
	void closeEvent(QCloseEvent *event) override{
		Close();
	}
	void paintEvent(QPaintEvent *event) override;
public:
	void Intialzation();
	void Init();
	void Close();
	void ROSset(ros::NodeHandle *);
public:
	QTimer *time;
	lDiff AMR;
	lMap map;
	int i;
	lLidar lidar;
	float q;
	QScrollBar *Scroll;
	ros::Publisher pub;
public:
	virtual void Draw(QPainter*);
	virtual void OnTimer();

	
};
#endif
