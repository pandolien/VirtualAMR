#ifndef __LLINE_H__
#define __LLINE_H__
class lLine{
public:
	lLine();
	~lLine();
public:
	int s,e;
	void Set(int, int);
};
#endif
