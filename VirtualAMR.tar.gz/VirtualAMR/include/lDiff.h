#ifndef __LDIFF_H__
#define __LDIFF_H__
#include <ros/ros.h>
#include "dhMat.h"
#include "dhVector.h"
#include <math.h>
#include <QPainter>
#include <tf/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include <nav_msgs/Odometry.h>
class lDiff{
public:
	lDiff();
	~lDiff();
public:

	void Initialzation();
	void Init(float w,float h);
	void RosInit(ros::NodeHandle *n);
	void SetWheelDistance(float);
	void SetWheelRadius(float);
public:
	float r;
	float d;
	dhVector x;
	dhVector buf[4];
	dhMat h;
	float s;
	geometry_msgs::TransformStamped odom;
	tf::TransformBroadcaster tfb;
	ros::Publisher pub;
	nav_msgs::Odometry msg;
public:
	void FK(float,float);
	void IK(float,float);
	void Update(QPainter*);
	void RosUpdate();

};
#endif
