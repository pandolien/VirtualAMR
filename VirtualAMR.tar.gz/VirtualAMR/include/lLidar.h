#ifndef __LLIDAR_H__
#define __LLIDAR_H__
#include "dhMat.h"
#include "dhVector.h"
#include <QPainter>

#include <ros/ros.h>
#include "sensor_msgs/LaserScan.h"
class lLidar{
public:
	lLidar();
	~lLidar();
public:
	void Initialzation();
	void Init(int,float,float,float);
	void Close();
	void RosInit(void*,const char*,int);
public:
	dhMat h;
	float *Dis;
	int n;
	float Max,Min,L;
	sensor_msgs::LaserScan scan;
	ros::Publisher pub;
	float s;
public:
	dhVector meet(dhVector,dhVector,dhVector,dhVector);
	void Scan(void*,void*);
	void Draw(void *,QPainter*);
	void RosUpdate();
};

#endif
