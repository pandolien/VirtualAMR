#include "lLine.h"
lLine::lLine(){
	s = 0;
	e = 0;
}
lLine::~lLine(){
	s = 0;
	e = 0;
}
void lLine::Set(int s,int e){
	this->s = s;
	this->e = e;
}
