#include "CMainWin.h"
#include "dhMat.h"
void CMainWin::paintEvent(QPaintEvent *event){
	Q_UNUSED(event);
	QPainter painter(this);
	painter.fillRect(rect(),Qt::white);
	painter.setPen(Qt::black);
	Draw(&painter);
}

void CMainWin::Intialzation(){
	time = NULL;
	Scroll = NULL;
	i = 0;
}
void CMainWin::Init(){
	dhMat h;
	time = new QTimer(this);
	Scroll = new QScrollBar(Qt::Vertical,this);
	connect(time,&QTimer::timeout,this,&CMainWin::OnTimer);
	
	
	time->start(100);
	AMR.Init(15,7);
	//map.Init(100,60);
	lidar.Init(1000,30,-30,1000);
	
	
	AMR.SetWheelDistance(7);//
	AMR.SetWheelRadius(2.2);//Wheel Size
	AMR.h = h.Trans(400,400,0)*h.RotZ(RAD(-90))*h.RotX(RAD(180));
	map.h = h.Trans(400,400,0)*h.RotZ(RAD(-90))*h.RotX(RAD(180));
	map.BoxMap(100,200);
	q = 0;
}
void CMainWin::Close(){
	map.Close();
	lidar.Close();
	ros::shutdown();
}
void CMainWin::ROSset(ros::NodeHandle *n){
	
	lidar.RosInit(n,"LiderScan",10);
	AMR.RosInit(n);
}

void CMainWin::Draw(QPainter *pDC){
	float x1,x2,x3,x4;
	float y1,y2,y3,y4;
	float pxu,pyu;
	dhVector v;
	v.x = 100*sin(RAD(i));
	v.y = 100*cos(RAD(i));
	i +=1;
	dhMat hro = AMR.h*AMR.h.Trans(AMR.x.x,AMR.x.y,0)*AMR.h.RotZ(RAD(AMR.x.z));

	AMR.IK(0.01,0.001);
	AMR.Update(pDC);
	map.Draw(pDC);
	lidar.Scan(&AMR,&map);
	AMR.RosUpdate();
	//lidar.Draw(&AMR,pDC);
	lidar.RosUpdate();
}

void CMainWin::OnTimer(){
	update();
}
