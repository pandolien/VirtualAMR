#include "main.h"
int main(int argc,char **argv){
	QApplication app(argc,argv);
	ros::init(argc,argv,"test");
	ros::NodeHandle n;
	CMainWin win;
	
	//ros::AsyncSpinner spiner(1);
	//spiner.start();
	win.ROSset(&n);
	win.resize(1200,800);
	win.show();
	
	return app.exec();
}
