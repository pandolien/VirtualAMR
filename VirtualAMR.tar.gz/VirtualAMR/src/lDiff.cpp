#include "lDiff.h"
lDiff::lDiff(){
	Initialzation();
}
lDiff::~lDiff(){
	
}
void lDiff::Initialzation(){
	
	odom.header.frame_id = "odom";
	odom.child_frame_id = "base_link";
}
void lDiff::Init(float w,float h){
	buf[0] = dhVector(w/2,h/2,0);
	buf[1] = dhVector(-w/2,h/2,0);
	buf[2] = dhVector(w/2,-h/2,0);
	buf[3] = dhVector(-w/2,-h/2,0);
}

void lDiff::RosInit(ros::NodeHandle *n){
	pub= n->advertise<nav_msgs::Odometry>("/odom",10);
	msg.header.frame_id = "odom";
	msg.child_frame_id = "base_link";
}
void lDiff::SetWheelDistance(float R){r = R;}
void lDiff::SetWheelRadius(float D){d = D;}
void lDiff::IK(float v,float w){
	float wl,wr;
	float r = 1/this->r;
	float d = (this->d/2)/this->r;
	wl = r*v-d*w;
	wr = r*v+d*w;
	FK(wl,wr);
}
void lDiff::FK(float wl,float wr){
	float dx,dy,dq,r2,t,c,s;
	t = RAD(x.z);
	r2 = r/2;
	
	c = cos(t);
	s = sin(t);
	
	dx = r2 * c * wl + r2 * c * wr;
	dy = r2 * s * wl + r2 * s * wr;
	dq = -r2 * d * wl + r2 * d * wr;
	
	x.x += dx;
	x.y += dy;
	x.z += DEG(dq);
}
void lDiff::Update(QPainter* pDC){
	int i;
	dhVector buf2[4];
	for(i = 0 ; i< 4;i++){
		buf2[i] = h*h.Trans(x.x,x.y,0)*h.RotZ(RAD(x.z))*buf[i];
	}
	pDC->drawLine(buf2[0].x,buf2[0].y,
			buf2[1].x,buf2[1].y);
	pDC->drawLine(buf2[1].x,buf2[1].y,
			buf2[3].x,buf2[3].y);
	pDC->drawLine(buf2[3].x,buf2[3].y,
			buf2[2].x,buf2[2].y);
	pDC->drawLine(buf2[2].x,buf2[2].y,
			buf2[0].x,buf2[0].y);
}
void lDiff::RosUpdate(){
	float q = RAD(x.z)/2;
	msg.header.stamp = ros::Time::now();
	msg.pose.pose.position.x = x.x;
	msg.pose.pose.position.y = x.y;
	msg.pose.pose.position.z = 0;
	
	msg.pose.pose.orientation.x = 0;
	msg.pose.pose.orientation.y = 0;
	msg.pose.pose.orientation.z = sin(q);
	msg.pose.pose.orientation.w = cos(q);
	pub.publish(msg);
	
	odom.header.stamp = ros::Time::now();
	odom.transform.translation.x = x.x;
	odom.transform.translation.y = x.y;
	odom.transform.translation.z = 0;
	odom.transform.rotation.x = 0;
	odom.transform.rotation.y = 0;
	odom.transform.rotation.z = sin(q);
	odom.transform.rotation.w = cos(q);
	
	tfb.sendTransform(odom);
}
