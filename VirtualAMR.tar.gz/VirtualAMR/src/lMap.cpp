#include "lMap.h"
lMap::lMap(){
	Initialzation();
}
lMap::~lMap(){
	Close();
}
void lMap::Initialzation(){
	pLn = NULL;
	pVt = NULL;
	nLn = 0;
	nVt = 0;
}
void lMap::Init(int nln,int nvt){
	Close();
	pLn = new lLine[nln];
	pVt = new dhVector[nvt];
	nLn = nln;
	nVt = nvt;
}
void lMap::Close(){
	if(pLn == NULL)delete(pLn);
	pLn = NULL;
	if(pVt == NULL)delete(pVt);
	pVt = NULL;
	nLn = 0;
	nVt = 0;
}
void lMap::Load(const char *name){
	
}
void lMap::BoxMap(int w,int h){
	Init(4,4);
	pLn[0].Set(0,1);
	pLn[1].Set(1,3);
	pLn[2].Set(3,2);
	pLn[3].Set(2,0);
	pVt[0] = dhVector(-w/2,-h/2,0);
	pVt[1] = dhVector(-w/2,h/2,0);
	pVt[2] = dhVector(w/2,-h/2,0);
	pVt[3] = dhVector(w/2,h/2,0);
	for(int i = 0; i< 4;i++){
		pVt[i] = this->h * pVt[i];
	}
}
void lMap::Draw(QPainter* pDC){
	if(pLn == NULL||pVt == NULL) return;
	int i;
	for(i = 0;i< nLn;i++){
		int s,e;
		s = pLn[i].s;
		e = pLn[i].e;
		pDC->drawLine(pVt[s].x,pVt[s].y,
				pVt[e].x,pVt[e].y);
	}
	
	
}
