#include "lLidar.h"
#include "lDiff.h"
#include "lMap.h"
lLidar::lLidar(){
	Initialzation();
}
lLidar::~lLidar(){
	Close();
}
void lLidar::Initialzation(){
	Dis = NULL;
	L = 0;
	Max = 0;
	Min = 0;
}
void lLidar::Init(int n,float max,float min,float l){
	Close();
	Dis = new float[n];
	L = l;
	this->n = n;
	Max = max;
	Min = min;
}
void lLidar::RosInit(void *n, const char* name,int num){
	ros::NodeHandle *nh = (ros::NodeHandle*)n;
	pub = nh->advertise<sensor_msgs::LaserScan>(name, num);
	float Ang = (Max-Min)/this->n;
	scan.header.frame_id = "base_link";
	scan.angle_min = RAD(Min);
	scan.angle_max = RAD(Max);
	scan.angle_increment =  ABS(RAD(Ang));  // Angular resolution of the laser scan
	scan.time_increment = 0.1/this->n;      // Time between measurements [seconds]
	scan.scan_time = 0.1;             // Time between scans [seconds]
	scan.range_min = 0.0;             // Minimum range value [meters]
	scan.range_max = L;            // Maximum range value [meters]
}
void lLidar::Close(){
	if(Dis) delete[](Dis);
	Dis = NULL;
}
void lLidar::Scan(void* AMR,void * Object){
	dhVector x1,x2,x3,x4;
	dhVector Max1,Min1;
	dhVector Max2,Min2;
	int i,j;
	float Ang;
	bool Check1;
	bool Check2;
	lDiff *amr = (lDiff*)AMR;
	lMap *map = (lMap*)Object;
	dhMat hbl = amr->h * h.Trans(amr->x.x,amr->x.y,0)*h.RotZ(RAD(amr->x.z))*h;
	x1.x = hbl.v[12];
	x1.y = hbl.v[13];
	
	_RPY rpy = hbl.RPY();
	Ang = Max - Min;
	for(i = 0 ;i< n;i++){
		dhVector v;
		float deg = Max - ABS(Ang)*((float)(i)/(n-1));
		v.x = L*cos(RAD(deg));
		v.y = L*sin(RAD(deg));
		//printf("%f\n",deg);
		x2 = hbl*v;
		Dis[i] = L;
		
		for(j = 0;j < map->nLn;j++){
			int S = map->pLn[j].s;
			int E = map->pLn[j].e;
			x3 = map->pVt[S];
			x4 = map->pVt[E];
			dhVector P = meet(x1,x2,x3,x4);
			Check1 = false;
			Check2 = false;
			if(P.x == 0&&P.y == 0) continue;
			Max1.x = MAX(x1.x,x2.x);
			Min1.x = MIN(x1.x,x2.x);
			Max1.y = MAX(x1.y,x2.y);
			Min1.y = MIN(x1.y,x2.y);
			
			if(P.x <= Max1.x&&P.x >= Min1.x&&P.y <= Max1.y&&P.y >= Min1.y){
				Check1 = true;	
			}
			Max2.x = MAX(x3.x,x4.x);
			Min2.x = MIN(x3.x,x4.x);
			Max2.y = MAX(x3.y,x4.y);
			Min2.y = MIN(x3.y,x4.y);
			if((P.x <= Max2.x&&P.x >= Min2.x)&&(P.y <= Max2.y&&P.y >= Min2.y)){
				Check2 = true;
			}
			if(Check1){
				dhVector L = x1 - P;
				if(Dis[i] > L.Norm())Dis[i] = L.Norm();
			}
		}
	}
	//printf("\n");
	//printf("\n");
}
dhVector lLidar::meet(dhVector x1,dhVector x2,dhVector x3,dhVector x4){
	dhVector v;
	float x;
	x = (x1.x-x2.x)*(x3.y-x4.y)-(x1.y-x2.y)*(x3.x-x4.x);
	if(x == 0)return v;
	v.x = (x1.x*x2.y-x1.y*x2.x)*(x3.x-x4.x)-(x1.x-x2.x)*(x3.x*x4.y-x3.y*x4.x);
	v.y = (x1.x*x2.y-x1.y*x2.x)*(x3.y-x4.y)-(x1.y-x2.y)*(x3.x*x4.y-x3.y*x4.x);
	v.x = v.x/x;
	v.y = v.y/x;
	return v;
}
void lLidar::Draw(void *AMR,QPainter* pDC){
	int i;
	float x,y;
	float Ang = Max - Min;
	lDiff *amr = (lDiff*)AMR;
	dhMat hbl = amr->h * h.Trans(amr->x.x,amr->x.y,0)*h.RotZ(RAD(amr->x.z))*h;
	//printf("Start\n");
	for(i = 0;i < n;i++){
		float deg = Max - ABS(Ang)*((float)(i)/(n-1));
		dhVector v = dhVector(Dis[i]*cos(RAD(deg)),Dis[i]*sin(RAD(deg)),0);
		//printf("%f\n",Dis[i]);
		v = hbl*v;
		pDC->drawLine(hbl.v[12],hbl.v[13],v.x,v.y);
	}

}
void lLidar::RosUpdate(){
	scan.ranges.clear();
	scan.header.stamp = ros::Time::now();
	for(int i = 0; i< n;i++){scan.ranges.push_back(Dis[n-(i+1)]);}
	pub.publish(scan);
}

